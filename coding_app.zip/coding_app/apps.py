from django.apps import AppConfig


class CodingAppConfig(AppConfig):
    name = 'coding_app'
