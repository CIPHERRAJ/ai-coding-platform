from rest_framework import viewsets, status, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from .models import UserProfile, Problem, Submission
from .serializers import UserProfileSerializer, ProblemSerializer, SubmissionSerializer
from .utils import assess_initial_skill, evaluate_submission, get_ai_help

@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def register_api(request):
    username = request.data.get('username')
    password = request.data.get('password')
    if not username or not password:
        return Response({'error': 'Username and password required'}, status=400)
    
    if User.objects.filter(username=username).exists():
        return Response({'error': 'Username already exists'}, status=400)
    
    user = User.objects.create_user(username=username, password=password)
    token, _ = Token.objects.get_or_create(user=user)
    return Response({'token': token.key, 'username': user.username})

@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def login_api(request):
    username = request.data.get('username')
    password = request.data.get('password')
    user = authenticate(username=username, password=password)
    
    if user:
        token, _ = Token.objects.get_or_create(user=user)
        return Response({'token': token.key, 'username': user.username})
    return Response({'error': 'Invalid credentials'}, status=400)

@api_view(['POST'])
def assessment_api(request):
    submissions = request.data.get('submissions', [])
    # submissions format: [{'question': '...', 'code': '...'}, ...]
    
    skill_level = assess_initial_skill(submissions)
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    profile.skill_level = skill_level
    profile.save()
    
    return Response({'skill_level': skill_level})

@api_view(['GET'])
def dashboard_data(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    problems = Problem.objects.filter(difficulty=profile.skill_level)
    
    if profile.problems_solved > 5 and profile.skill_level == 'Beginner':
        problems = Problem.objects.filter(difficulty='Intermediate') | problems

    return Response({
        'profile': UserProfileSerializer(profile).data,
        'problems': ProblemSerializer(problems, many=True).data
    })

@api_view(['POST'])
def submit_code(request, problem_id):
    try:
        problem = Problem.objects.get(id=problem_id)
    except Problem.DoesNotExist:
        return Response({'error': 'Problem not found'}, status=404)
        
    code = request.data.get('code')
    is_correct, feedback = evaluate_submission(problem.description, code)
    
    Submission.objects.create(
        user=request.user,
        problem=problem,
        code=code,
        ai_feedback=feedback,
        is_correct=is_correct
    )
    
    if is_correct:
        profile = request.user.userprofile
        profile.problems_solved += 1
        # Simple level up logic
        if profile.problems_solved == 3 and profile.skill_level == 'Beginner':
            profile.skill_level = 'Intermediate'
        elif profile.problems_solved == 8 and profile.skill_level == 'Intermediate':
            profile.skill_level = 'Advanced'
        profile.save()
        
    return Response({'is_correct': is_correct, 'feedback': feedback})

@api_view(['POST'])
def ask_ai(request):
    question = request.data.get('question')
    code = request.data.get('code')
    context = request.data.get('context')
    
    answer = get_ai_help(context, code, question)
    return Response({'answer': answer})

@api_view(['GET'])
def user_history(request):
    submissions = Submission.objects.filter(user=request.user).order_by('-timestamp')
    return Response(SubmissionSerializer(submissions, many=True).data)
