from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_api, name='api_register'),
    path('login/', views.login_api, name='api_login'),
    path('assessment/', views.assessment_api, name='api_assessment'),
    path('dashboard/', views.dashboard_data, name='api_dashboard'),
    path('submit/<int:problem_id>/', views.submit_code, name='api_submit'),
    path('ask/', views.ask_ai, name='api_ask'),
    path('history/', views.user_history, name='api_history'),
]
