from django.contrib import admin
from .models import UserProfile, Problem, Submission

admin.site.register(UserProfile)
admin.site.register(Problem)
admin.site.register(Submission)